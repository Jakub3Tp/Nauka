import { useState } from 'react';
import './App.css';

function Square({ value, onSqareClick }) {
  // const [value, setValue] = useState(null);

  function handleClick(){
     console.log(`Kliknięto ${value}!`);
    //setValue('X');
  }

  return (
    <button 
          className='square' 
          onClick={onSqareClick}
        >
          {value}
        </button>
    );
  }

  export default function Board(){
    const [squares, setSquares] = useState(Array(9).fill(null));
    const [xIsNext, setXIsNext] = useState(true)

    function handleClick(x) {
      if(squares[x]){
        return;
      }
      const nextSquares = squares.slice();
      if(xIsNext) {
        nextSquares[x] = 'X';
      } else {
        nextSquares[x] = 'O';
      }
      // nextSquares[x] = (xIsNext ? 'X' : 'O');
      setXIsNext(!xIsNext);
      setSquares(nextSquares);
    }

  return (
  <>
    <div className='board-row'>
      <Square value={squares[0]} onSqareClick={() => handleClick(0)}/>
      <Square value={squares[1]} onSqareClick={() => handleClick(1)}/>
      <Square value={squares[2]} onSqareClick={() => handleClick(2)}/>
    </div>
    <div className='board-row'>
      <Square value={squares[3]} onSqareClick={() => handleClick(3)}/>
      <Square value={squares[4]} onSqareClick={() => handleClick(4)}/>
      <Square value={squares[5]} onSqareClick={() => handleClick(5)}/>
    </div>
    <div className='board-row'>
      <Square value={squares[6]} onSqareClick={() => handleClick(6)}/>
      <Square value={squares[7]} onSqareClick={() => handleClick(7)}/>
      <Square value={squares[8]} onSqareClick={() => handleClick(8)}/>
    </div>
  </>
  );
}

function calculateWinner(squares) {
  const lines = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [6, 4, 2]
  ];

  for(let i = 0; i <lines.length; i++) {
    const [a, b, c] = lines[i];
    if(squares[a] && squares[a] === squares[b] && squares[b] && squares[c]) {
      return squares[a]
    }
  }

  return null;
}
