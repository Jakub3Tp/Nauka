import { useState } from "react";

function PozycjaListyZakupow({nazwa, czyKupione}){
    const [isBought, setIsBought] = useState(czyKupione); // stan isBought z wart. pocz. z propsa

    function handleClick() {
        setIsBought(true)
    }

    if(isBought){
        return (
            <li>
                <del>{nazwa} ✅</del>
            </li>
        );
    }else {
        return (
        <li>
            {nazwa}{" "}
            <button type="button" onClick={handleClick}>
            Już kupione
            </button></li>); 
    }
}

export function ListaZakupow(){
    let zakupy = [
        {
            id: 1,
            nazwa: "Książka",
            czyKupione: false
        },
        {
            id: 2,
            nazwa: "Pendrive",
            czyKupione: true
        }
    ];

    let PozycjeZakupow = zakupy.map((pozycja) => {
        return (
           <PozycjaListyZakupow
            key={pozycja.id}
            nazwa={pozycja.nazwa}
            czyKupione={pozycja.czyKupione}
            /> 
        );
    });

    let wyswietlanie;
    if (zakupy.length == 0) {
        wyswietlanie = <p>Lista zakupów jest pusta</p>
    } else {
       wyswietlanie = <ul>{PozycjeZakupow}</ul>;
    }

    return (
        <>
            <h1>Moja lista zakupów</h1>
            <ul>
            {PozycjeZakupow}
            </ul>
        </> 
    ); 
}

