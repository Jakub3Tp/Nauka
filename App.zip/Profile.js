// npm i- create-app

export function Profile({img, name, isGiant}) {
  let height = "30vh";
  if(isGiant === true){
    height = "50vh";
  }

  return (
    <img 
    src={img}
    alt={name}
    style={{ height: height }} />
  );
}
