import logo from './logo.svg';
import './App.css';
import { Profile } from './Profile';
import { ListaZakupow } from './ListaZakupow';

export default function Gallery() {
  let catsINboxes = true;

  const logo = <img src={catsINboxes ? "logo192.png" : "logo512.png"} />

  const czyPokazacListeZakupow = true;

  return (
    <section>
      {czyPokazacListeZakupow && <ListaZakupow />}




      <hr />
      {logo}
      <h1>{catsINboxes ? "Koty" : "Psy" } w pudełkach</h1>
      <Profile 
      img="https://i.imgur.com/RqJBDyn.jpeg" 
      name="Kot"
      />
      <Profile 
      img="https://i.imgur.com/Sibekhc.jpeg" 
      name="Koteł"
      />
      <Profile 
      img="https://i.imgur.com/9lL6u.jpeg" 
      name="Kotek"
      isGiant={true}
      />
    </section>
  )
}